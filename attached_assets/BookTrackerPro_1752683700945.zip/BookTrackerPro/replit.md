# Wedding Invitation Website

## Overview

This is a modern, mobile-friendly wedding invitation website built with React, Express.js, and PostgreSQL. The application features a beautiful one-page design with sections for wedding details, RSVP functionality, countdown timer, photo gallery, and gift registry information. It uses shadcn/ui components for a polished, accessible user interface with a romantic wedding theme.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom wedding theme colors (blush, ivory, soft-gold, lavender)
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Validation**: Zod for runtime type checking and validation
- **Session Management**: Built-in session handling with connect-pg-simple
- **API Design**: RESTful API endpoints with proper error handling

### Database Design
- **Primary Database**: PostgreSQL (configured via DATABASE_URL)
- **ORM**: Drizzle ORM with schema-first approach
- **Migration Strategy**: Drizzle migrations with push commands
- **Schema Location**: Shared schema definitions in `/shared/schema.ts`

## Key Components

### RSVP System
- **Schema**: Name, email, guest count, meal preference, and custom message
- **Validation**: Zod schema validation on both client and server
- **Storage**: PostgreSQL with Drizzle ORM
- **Fallback**: In-memory storage for development

### UI Components
- **Wedding-specific**: Countdown timer, floating hearts animation, image gallery
- **Form Components**: Input, Select, Textarea with validation states
- **Feedback**: Toast notifications for user actions
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints

### Styling System
- **Theme**: Custom wedding color palette with CSS variables
- **Typography**: Great Vibes font for elegant headings
- **Components**: Consistent design system with shadcn/ui
- **Animations**: Floating hearts and smooth transitions

## Data Flow

1. **RSVP Submission**:
   - User fills form → React Hook Form validation → Zod schema validation
   - API call to `/api/rsvp` → Server validation → Database storage
   - Success/error feedback via toast notifications

2. **Data Retrieval**:
   - TanStack Query manages server state
   - Automatic caching and background refetching
   - Optimistic updates for better UX

3. **Real-time Features**:
   - Countdown timer updates every second
   - Photo gallery with modal interactions
   - Social sharing functionality

## External Dependencies

### Core Libraries
- **React Ecosystem**: React 18, React Hook Form, TanStack Query
- **UI/UX**: Radix UI primitives, Lucide React icons, Tailwind CSS
- **Backend**: Express.js, Drizzle ORM, Zod validation
- **Database**: Neon serverless PostgreSQL driver

### Development Tools
- **Build System**: Vite with React plugin
- **Type Safety**: TypeScript throughout the stack
- **Code Quality**: ESLint integration via Vite
- **Development**: Hot module replacement and error overlay

### Third-party Services
- **Database**: Neon serverless PostgreSQL
- **Maps**: Google Maps integration for venue locations
- **Media**: Image hosting and video embedding support
- **Social**: WhatsApp, Instagram, Email sharing

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `/dist/public`
- **Backend**: esbuild bundles server code to `/dist/index.js`
- **Database**: Drizzle migrations via `db:push` command

### Environment Configuration
- **Database**: `DATABASE_URL` environment variable required
- **Development**: `NODE_ENV=development` for dev features
- **Production**: `NODE_ENV=production` for optimized builds

### File Structure
- **Client**: React app in `/client` directory
- **Server**: Express API in `/server` directory
- **Shared**: Common types and schemas in `/shared` directory
- **Database**: Migrations in `/migrations` directory

### Development Workflow
- `npm run dev`: Start development server with hot reloading
- `npm run build`: Create production build
- `npm run start`: Run production server
- `npm run db:push`: Apply database schema changes

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout, and optimized for both development experience and production performance.