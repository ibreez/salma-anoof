import { useState } from "react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

interface ImageGalleryProps {
  images: Array<{
    src: string;
    alt: string;
  }>;
}

export function ImageGallery({ images }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {images.map((image, index) => (
        <Dialog key={index}>
          <DialogTrigger asChild>
            <div className="gallery-item cursor-pointer">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-64 object-cover rounded-2xl shadow-lg"
                onClick={() => setSelectedImage(image.src)}
              />
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <img
              src={image.src}
              alt={image.alt}
              className="w-full h-auto rounded-lg"
            />
          </DialogContent>
        </Dialog>
      ))}
    </div>
  );
}
