import { Heart } from "lucide-react";

export function FloatingHearts() {
  const hearts = Array.from({ length: 9 }, (_, i) => ({
    id: i,
    left: `${(i + 1) * 10}%`,
    animationDelay: `${i * 0.5}s`,
  }));

  return (
    <div className="floating-hearts">
      {hearts.map((heart) => (
        <Heart
          key={heart.id}
          className="heart"
          style={{
            left: heart.left,
            animationDelay: heart.animationDelay,
          }}
        />
      ))}
    </div>
  );
}
