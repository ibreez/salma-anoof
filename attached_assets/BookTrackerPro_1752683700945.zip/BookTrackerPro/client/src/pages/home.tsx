import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Heart, MapPin, Clock, Calendar, Phone, Mail, Gift, University, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { CountdownTimer } from "@/components/ui/countdown-timer";
import { FloatingHearts } from "@/components/ui/floating-hearts";
import { ImageGallery } from "@/components/ui/image-gallery";
import { apiRequest } from "@/lib/queryClient";
import { insertRsvpSchema } from "@shared/schema";

const formSchema = insertRsvpSchema.extend({
  guestCount: z.coerce.number().min(1, "Please select number of guests"),
});

type FormData = z.infer<typeof formSchema>;

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [copiedBank, setCopiedBank] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      guestCount: 1,
      mealPreference: "",
      message: "",
    },
  });

  const rsvpMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/rsvp", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "RSVP Submitted Successfully!",
        description: "Thank you for your RSVP! We're excited to celebrate with you.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/rsvp"] });
    },
    onError: (error) => {
      toast({
        title: "Error submitting RSVP",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    rsvpMutation.mutate(data);
  };

  const copyBankDetails = async () => {
    const bankDetails = `Account Name: John & Lisa Wedding Fund
Account Number: 1234567890
Routing Number: 987654321
Bank: First National Bank`;
    
    try {
      await navigator.clipboard.writeText(bankDetails);
      setCopiedBank(true);
      setTimeout(() => setCopiedBank(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please copy the bank details manually",
        variant: "destructive",
      });
    }
  };

  const copyBankDetails1 = async () => {
    const bankDetails = `Account Name: John & Lisa Wedding Fund
  Account Number: 1234567890
  Routing Number: 987654321
  Bank: First National Bank`;

    try {
      await navigator.clipboard.writeText(bankDetails);
      setCopiedBank(true);
      setTimeout(() => setCopiedBank(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please copy the bank details manually",
        variant: "destructive",
      });
    }
  };

  const galleryImages = [
    {
      src: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Couple laughing together in garden",
    },
    {
      src: "https://images.unsplash.com/photo-1537420327992-d6e192287183?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Couple embracing on beach at sunrise",
    },
    {
      src: "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Couple sharing tender moment with engagement ring",
    },
    {
      src: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Couple walking hand in hand through scenic pathway",
    },
    {
      src: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Couple having romantic picnic in park",
    },
    {
      src: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      alt: "Romantic couple portrait at sunset",
    },
  ];

  return (
    <div className="font-lato bg-[var(--ivory)] relative">
      <FloatingHearts />
      
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white bg-opacity-95 backdrop-blur-md z-50 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex justify-center py-3">
            <div className="flex space-x-8">
              <a href="#home" className="text-[var(--warm-gray)] hover:text-[var(--blush)] transition-colors duration-300 text-sm font-medium">Home</a>
              <a href="#details" className="text-[var(--warm-gray)] hover:text-[var(--blush)] transition-colors duration-300 text-sm font-medium">Details</a>
              <a href="#rsvp" className="text-[var(--warm-gray)] hover:text-[var(--blush)] transition-colors duration-300 text-sm font-medium">RSVP</a>
              <a href="#gallery" className="text-[var(--warm-gray)] hover:text-[var(--blush)] transition-colors duration-300 text-sm font-medium">Gallery</a>
              <a href="#gifts" className="text-[var(--warm-gray)] hover:text-[var(--blush)] transition-colors duration-300 text-sm font-medium">Gifts</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen gradient-bg flex items-center justify-center px-4 pt-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="fade-in">
            <h1 className="font-great-vibes text-6xl md:text-8xl text-[var(--warm-gray)] mb-4">Anoof & Salma</h1>
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            <p className="text-xl md:text-2xl text-[var(--warm-gray)] mb-8 font-light">Friday, October 10, 2025</p>
            
            {/* Wedding Video Section */}
            <div className="max-w-3xl mx-auto mb-12">
              <Card className="bg-white rounded-2xl p-6 card-shadow">
                <h3 className="text-2xl font-great-vibes text-[var(--warm-gray)] mb-4">
                  Wedding Invitation
                </h3>
                <div className="relative pb-[177.78%] h-0 overflow-hidden rounded-xl">
                  <video
                    className="absolute top-0 left-0 w-full h-full rounded-xl object-cover"
                    controls
                    poster="public/404.png" // optional
                  >
                    <source src="shared/Anoof-card.mp4" type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
              </Card>
            </div>



            {/* Countdown Timer */}
            <CountdownTimer targetDate="2025-10-10T09:00:00" />
          </div>
        </div>
      </section>

      {/* Event Details */}
      <section id="details" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-great-vibes text-5xl md:text-6xl text-[var(--warm-gray)] mb-4">Wedding Details</h2>
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            <p className="text-lg text-[var(--warm-gray)] max-w-2xl mx-auto">Join us as we celebrate our love and begin our journey together as husband and wife</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Ceremony Details */}
            <div className="slide-in-left">
              <Card className="bg-gradient-to-br from-[var(--blush)] to-[var(--lavender)] rounded-2xl p-8 card-shadow h-full">
                <div className="text-center mb-6">
                  <Heart className="text-white text-4xl mb-4 mx-auto" />
                  <h3 className="font-great-vibes text-3xl text-white mb-2">Ceremony</h3>
                </div>
                <div className="space-y-4 text-white">
                  <div className="flex items-center">
                    <Calendar className="w-6 mr-3" />
                    <span>Friday, October 10, 2025</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-6 mr-3" />
                    <span>4:00 PM</span>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="w-6 mr-3 mt-1" />
                    <div>
                      <p>St. Mary's Cathedral</p>
                      <p className="text-sm opacity-90">123 Wedding Street, Love City, LC 12345</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 rounded-xl overflow-hidden">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3048.4!2d-74.006!3d40.712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDBCMDQyJzQzLjIiTiA3NMKwMDAnMjEuNiJX!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus" 
                    width="100%" 
                    height="200" 
                    style={{border: 0}} 
                    allowFullScreen 
                    loading="lazy">
                  </iframe>
                </div>
                
                <div className="mt-4 flex space-x-3">
                  <Button asChild className="flex-1 bg-white text-[var(--blush)] hover:bg-opacity-90">
                    <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer">
                      <MapPin className="w-4 h-4 mr-2" />
                      Get Directions
                    </a>
                  </Button>
                  <Button asChild className="flex-1 bg-white text-[var(--blush)] hover:bg-opacity-90">
                    <a href="#" onClick={(e) => e.preventDefault()}>
                      <Calendar className="w-4 h-4 mr-2" />
                      Add to Calendar
                    </a>
                  </Button>
                </div>
              </Card>
            </div>

            {/* Reception Details */}
            <div className="slide-in-left">
              <Card className="bg-gradient-to-br from-[var(--soft-gold)] to-[var(--deep-rose)] rounded-2xl p-8 card-shadow h-full">
                <div className="text-center mb-6">
                  <Gift className="text-white text-4xl mb-4 mx-auto" />
                  <h3 className="font-great-vibes text-3xl text-white mb-2">Reception</h3>
                </div>
                <div className="space-y-4 text-white">
                  <div className="flex items-center">
                    <Calendar className="w-6 mr-3" />
                    <span>Friday, October 10, 2025</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-6 mr-3" />
                    <span>7:00 PM - 12:00 AM</span>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="w-6 mr-3 mt-1" />
                    <div>
                      <p>Grand Ballroom at Rose Hotel</p>
                      <p className="text-sm opacity-90">456 Reception Avenue, Love City, LC 12345</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 rounded-xl overflow-hidden">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3048.4!2d-74.006!3d40.712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDBCMDQyJzQzLjIiTiA3NMKwMDAnMjEuNiJX!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus" 
                    width="100%" 
                    height="200" 
                    style={{border: 0}} 
                    allowFullScreen 
                    loading="lazy">
                  </iframe>
                </div>
                
                <div className="mt-4 flex space-x-3">
                  <Button asChild className="flex-1 bg-white text-[var(--deep-rose)] hover:bg-opacity-90">
                    <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer">
                      <MapPin className="w-4 h-4 mr-2" />
                      Get Directions
                    </a>
                  </Button>
                  <Button asChild className="flex-1 bg-white text-[var(--deep-rose)] hover:bg-opacity-90">
                    <a href="#" onClick={(e) => e.preventDefault()}>
                      <Calendar className="w-4 h-4 mr-2" />
                      Add to Calendar
                    </a>
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* RSVP Section */}
      <section id="rsvp" className="py-20 gradient-bg">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-great-vibes text-5xl md:text-6xl text-[var(--warm-gray)] mb-4">RSVP</h2>
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            <p className="text-lg text-[var(--warm-gray)] max-w-2xl mx-auto">We're excited to celebrate with you! Please let us know if you'll be joining us for our special day.</p>
          </div>

          <Card className="bg-white rounded-2xl p-8 card-shadow">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name" className="text-[var(--warm-gray)] font-medium">Full Name *</Label>
                  <Input
                    id="name"
                    {...form.register("name")}
                    placeholder="Enter your full name"
                    className="mt-2 focus:border-[var(--blush)] focus:ring-[var(--blush)]"
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="email" className="text-[var(--warm-gray)] font-medium">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    {...form.register("email")}
                    placeholder="Enter your email"
                    className="mt-2 focus:border-[var(--blush)] focus:ring-[var(--blush)]"
                  />
                  {form.formState.errors.email && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="guestCount" className="text-[var(--warm-gray)] font-medium">Number of Guests *</Label>
                  <Select onValueChange={(value) => form.setValue("guestCount", parseInt(value))}>
                    <SelectTrigger className="mt-2 focus:border-[var(--blush)] focus:ring-[var(--blush)]">
                      <SelectValue placeholder="Select number of guests" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Guest</SelectItem>
                      <SelectItem value="2">2 Guests</SelectItem>
                      <SelectItem value="3">3 Guests</SelectItem>
                      <SelectItem value="4">4 Guests</SelectItem>
                      <SelectItem value="5">5+ Guests</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.guestCount && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.guestCount.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="mealPreference" className="text-[var(--warm-gray)] font-medium">Meal Preference</Label>
                  <Select onValueChange={(value) => form.setValue("mealPreference", value)}>
                    <SelectTrigger className="mt-2 focus:border-[var(--blush)] focus:ring-[var(--blush)]">
                      <SelectValue placeholder="Select meal preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="chicken">Chicken</SelectItem>
                      <SelectItem value="beef">Beef</SelectItem>
                      <SelectItem value="fish">Fish</SelectItem>
                      <SelectItem value="vegetarian">Vegetarian</SelectItem>
                      <SelectItem value="vegan">Vegan</SelectItem>
                      <SelectItem value="other">Other (please specify in message)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="message" className="text-[var(--warm-gray)] font-medium">Special Message (Optional)</Label>
                <Textarea
                  id="message"
                  {...form.register("message")}
                  placeholder="Share any special requests, dietary restrictions, or a lovely message for the couple..."
                  className="mt-2 focus:border-[var(--blush)] focus:ring-[var(--blush)] resize-none"
                  rows={4}
                />
              </div>

              <div className="text-center">
                <Button
                  type="submit"
                  disabled={rsvpMutation.isPending}
                  className="bg-gradient-to-r from-[var(--blush)] to-[var(--deep-rose)] text-white px-8 py-3 rounded-lg font-medium hover:from-[var(--deep-rose)] hover:to-[var(--blush)] transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  {rsvpMutation.isPending ? "Sending..." : "Send RSVP"}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </section>

      {/* Photo Gallery */}
      <section id="gallery" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-great-vibes text-5xl md:text-6xl text-[var(--warm-gray)] mb-4">Our Journey</h2>
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            <p className="text-lg text-[var(--warm-gray)] max-w-2xl mx-auto">A glimpse into our love story through memorable moments we've shared together</p>
          </div>

          <ImageGallery images={galleryImages} />
        </div>
      </section>

      {/* Gift Registry */}
      <section id="gifts" className="py-20 gradient-bg">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-great-vibes text-5xl md:text-6xl text-[var(--warm-gray)] mb-4">Gift Registry</h2>
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            <p className="text-lg text-[var(--warm-gray)] max-w-2xl mx-auto">Your presence is the greatest gift, but if you'd like to celebrate with us, here are some options</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Bank Details */}
            <Card className="bg-white rounded-2xl p-8 card-shadow">
              <div className="text-center mb-6">
                <University className="text-[var(--deep-rose)] text-4xl mb-4 mx-auto" />
                <h3 className="font-great-vibes text-3xl text-[var(--warm-gray)] mb-2">Monetary Gifts</h3>
                <p className="text-[var(--warm-gray)]">For those who prefer to give cash gifts</p>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-[var(--warm-gray)] mb-2">Bank Transfer Details</h4>
                  <div className="space-y-2 text-sm text-[var(--warm-gray)]">
                    <p><span className="font-medium">Account Name:</span> John & Lisa Wedding Fund</p>
                    <p><span className="font-medium">Account Number:</span> 1234567890</p>
                    <p><span className="font-medium">Routing Number:</span> 987654321</p>
                    <p><span className="font-medium">Bank:</span> First National Bank</p>
                  </div>
                </div>
                <div className="text-center">
                  <Button
                    onClick={copyBankDetails}
                    className="bg-gradient-to-r from-[var(--blush)] to-[var(--deep-rose)] text-white hover:from-[var(--deep-rose)] hover:to-[var(--blush)] transition-all duration-300 transform hover:scale-105"
                  >
                    {copiedBank ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                    {copiedBank ? "Copied!" : "Copy Details"}
                  </Button>
                </div>
              </div>
            </Card>

            {/* Bank Details */}
            <Card className="bg-white rounded-2xl p-8 card-shadow">
              <div className="text-center mb-6">
                <University className="text-[var(--deep-rose)] text-4xl mb-4 mx-auto" />
                <h3 className="font-great-vibes text-3xl text-[var(--warm-gray)] mb-2">Monetary Gifts</h3>
                <p className="text-[var(--warm-gray)]">For those who prefer to give cash gifts</p>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-[var(--warm-gray)] mb-2">Bank Transfer Details</h4>
                  <div className="space-y-2 text-sm text-[var(--warm-gray)]">
                    <p><span className="font-medium">Account Name:</span> John & Lisa Wedding Fund</p>
                    <p><span className="font-medium">Account Number:</span> 1234567890</p>
                    <p><span className="font-medium">Routing Number:</span> 987654321</p>
                    <p><span className="font-medium">Bank:</span> First National Bank</p>
                  </div>
                </div>
                <div className="text-center">
                  <Button
                    onClick={copyBankDetails}
                    className="bg-gradient-to-r from-[var(--blush)] to-[var(--deep-rose)] text-white hover:from-[var(--deep-rose)] hover:to-[var(--blush)] transition-all duration-300 transform hover:scale-105"
                  >
                    {copiedBank ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                    {copiedBank ? "Copied!" : "Copy Details"}
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Sharing */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="fade-in">
            <h3 className="font-great-vibes text-4xl text-[var(--warm-gray)] mb-4">Share Our Joy</h3>
            <p className="text-lg text-[var(--warm-gray)] mb-8">Help us spread the love by sharing our special day with friends and family</p>
            
            <div className="flex justify-center space-x-6">
              <Button asChild size="lg" className="bg-green-500 hover:bg-green-600 text-white rounded-full transition-all duration-300 transform hover:scale-110">
                <a href="https://wa.me/?text=Check%20out%20John%20and%20Lisa's%20wedding%20invitation!" target="_blank" rel="noopener noreferrer">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z"/>
                  </svg>
                </a>
              </Button>
              <Button asChild size="lg" className="bg-pink-500 hover:bg-pink-600 text-white rounded-full transition-all duration-300 transform hover:scale-110">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>
              </Button>
              <Button asChild size="lg" className="bg-blue-500 hover:bg-blue-600 text-white rounded-full transition-all duration-300 transform hover:scale-110">
                <a href="mailto:?subject=John%20and%20Lisa's%20Wedding&body=You're%20invited%20to%20John%20and%20Lisa's%20wedding!" target="_blank" rel="noopener noreferrer">
                  <Mail className="w-6 h-6" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="gradient-bg py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="fade-in">
            <h3 className="font-great-vibes text-4xl text-[var(--warm-gray)] mb-4">Thank You</h3>
            <p className="text-lg text-[var(--warm-gray)] mb-8 max-w-2xl mx-auto">
              We're so grateful for your love and support as we begin this new chapter together. 
              We can't wait to celebrate with you on our special day!
            </p>
            
            <div className="flex justify-center items-center space-x-8 mb-8">
              <div className="text-center">
                <Phone className="text-[var(--blush)] text-2xl mb-2 mx-auto" />
                <p className="text-[var(--warm-gray)]">
                  <span className="block font-medium">Call us</span>
                  <span className="text-sm">(555) 123-4567</span>
                </p>
              </div>
              <div className="text-center">
                <Mail className="text-[var(--deep-rose)] text-2xl mb-2 mx-auto" />
                <p className="text-[var(--warm-gray)]">
                  <span className="block font-medium">Email us</span>
                  <span className="text-sm">wedding@johnandlisa.com</span>
                </p>
              </div>
            </div>
            
            <div className="w-24 h-1 bg-[var(--deep-rose)] mx-auto mb-8"></div>
            
            <p className="text-[var(--warm-gray)] text-sm">
              Made with <Heart className="inline w-4 h-4 text-[var(--blush)]" /> by Anoof & Salma
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
