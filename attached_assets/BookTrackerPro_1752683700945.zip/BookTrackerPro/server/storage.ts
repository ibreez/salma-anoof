import { rsvps, type Rsvp, type InsertRsvp } from "@shared/schema";

export interface IStorage {
  createRsvp(rsvp: InsertRsvp): Promise<Rsvp>;
  getRsvps(): Promise<Rsvp[]>;
  getRsvpById(id: number): Promise<Rsvp | undefined>;
}

export class MemStorage implements IStorage {
  private rsvps: Map<number, Rsvp>;
  private currentId: number;

  constructor() {
    this.rsvps = new Map();
    this.currentId = 1;
  }

  async createRsvp(insertRsvp: InsertRsvp): Promise<Rsvp> {
    const id = this.currentId++;
    const rsvp: Rsvp = {
      ...insertRsvp,
      id,
      createdAt: new Date(),
    };
    this.rsvps.set(id, rsvp);
    return rsvp;
  }

  async getRsvps(): Promise<Rsvp[]> {
    return Array.from(this.rsvps.values());
  }

  async getRsvpById(id: number): Promise<Rsvp | undefined> {
    return this.rsvps.get(id);
  }
}

export const storage = new MemStorage();
